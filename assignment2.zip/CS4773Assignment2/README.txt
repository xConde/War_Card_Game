Implement at least 4 of the grasp and/or solid principles we have covered

GRASP:

Static polymorphism
* Public Class War
	This class provides several uses of a type of static polymorphism, method overloading. 
		Overloaded constructors for War.
		setHands vary on player quantity
		playerConfigurePoints vary on player quantity
Dynamic polymorphism
* Public Classes WarVariation1, WarVariation2, WarVariation3
	These classes provide uses for a type of dynamic polymorphism, method overriding in an
	inheritance hierarchy.
		Variation constructors utilize superclass. 
Inheritance
* Public Class Deck extends Hand & Public Classes WarVariation1, WarVariation2, 
WarVariation3 extend War

	Single Inheritance
	Public Class Deck demonstrate single inheritance. Subclasses inherit the features of one
	superclass.

	Hierarchical Inheritance
	Public Classes WarVariation1, WarVariation2, WarVariation3 demonstrate hierarchical inheritance
	such that one class serves as a super class (base class) for more than one sub class.  
	
	
